﻿using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Tachograph.Data.Context;
using Tachograph.Data.Models;
using Tachograph.Entity.DTOs;

namespace Tachograph.Data.Repository
{
    public class DriverRepository : IDriverRepository
    {
        private readonly ILogger<DriverRepository> _logger;
        protected readonly IDynamoDBContext _dynamodbcontext;
        protected readonly TachographDBContext _context;

        public DriverRepository(ILogger<DriverRepository> logger, IDynamoDBContext dynamoDBContext, TachographDBContext context)
        {
            _logger = logger;
            _dynamodbcontext = dynamoDBContext;
            _context = context;
        }

        public async Task<List<DriverDetails>> GetAllDriverList()
        {
            try
            {
                var data = await _dynamodbcontext.ScanAsync<DriverDetails>(
                  default).GetRemainingAsync();
                return data;
            }
            catch (Exception ex)
            {
                _logger.LogError("{DriverDetailsRepository - GetAllDriverList}", ex.Message);
                throw;
            }
        }

        public async Task<string> SaveDailyDriverActivity(DailyActivityLogs dailyActivityLogs)
        {
            try
            {
                DateTime currentDate = dailyActivityLogs.StartTime.Date;

                // Check Condition: Maximum 100 files per day for this driver
                int fileCountForDay = await _context.DailyActivityLogs
                  .Where(log => log.DriverID == dailyActivityLogs.DriverID && log.StartTime.Date == currentDate)
                  .CountAsync();

                if (fileCountForDay >= 100)
                {
                    return "Maximum limit of 100 files per day reached for this driver.";
                }

                // Check Condition: Maximum 30 unique drivers for this day
                int uniqueDriverCount = await _context.DailyActivityLogs
                  .Where(log => log.StartTime.Date == currentDate)
                  .Select(log => log.DriverID)
                  .Distinct()
                  .CountAsync();

                if (uniqueDriverCount >= 30)
                {
                    return "Maximum limit of 30 unique drivers reached for this day.";
                }

                // If all conditions pass, save the DailyActivityLogs to the database
                _context.DailyActivityLogs.Add(dailyActivityLogs);
                await _context.SaveChangesAsync();

                return "Daily driver activity saved successfully!";
            }
            catch (Exception ex)
            {
                _logger.LogError("{DriverDetailsRepository - SaveDailyDriverActivity}", ex.Message);
                throw;
            }
        }

        public async Task<DashboardDTO> GetDashBoardData()
        {
            try
            {
                var totalDrivingTicks = _context.DailyActivityLogs.Where(log => log.Activity == "Driving").AsEnumerable()
                  .Sum(log => (log.EndTime - log.StartTime).Ticks);

                var totalRestTicks = _context.DailyActivityLogs.Where(log => log.Activity == "Rest")
                  .AsEnumerable()
                  .Sum(log => (log.EndTime - log.StartTime).Ticks);

                TimeSpan totalDrivingTime = TimeSpan.FromTicks(totalDrivingTicks);
                TimeSpan totalRestTime = TimeSpan.FromTicks(totalRestTicks);

                double totalDrivingHours = totalDrivingTime.TotalHours;
                double totalRestHours = totalRestTime.TotalHours;

                var driverDetails = await _dynamodbcontext.ScanAsync<DriverDetails>(
                  default).GetRemainingAsync();

                var violations = _context.DailyActivityLogs
                  .AsEnumerable()
                  .Where(log => (log.EndTime - log.StartTime).TotalHours > 4)
                  .Join(
                    inner: driverDetails,
                    outerKeySelector: log => log.DriverID,
                    innerKeySelector: details => details.DriverId,
                    resultSelector: (log, details) => new ViolationDetailsDTO
                    {
                        DriverID = log.DriverID,
                        FirstName = details.FirstName,
                        LastName = details.LastName,
                        StartTime = log.StartTime,
                        EndTime = log.EndTime,
                        ViolationHours = (log.EndTime - log.StartTime).TotalHours.ToString("0.00")
                    }
                  )
                  .ToList();
                var restTimeViolations = _context.DailyActivityLogs.AsEnumerable()
                    .Where(log => (log.StartTime - log.EndTime).TotalMinutes < 45)
                    .Join(driverDetails,
                        log => log.DriverID,
                        details => details.DriverId,
                        (log, details) =>
                        {
                            TimeSpan duration = log.EndTime - log.StartTime;
                            double totalHours = duration.TotalMinutes / 60.0;

                            string violationHours = totalHours.ToString("0.00");

                          
                            return new ViolationDetailsDTO
                            {
                                DriverID = log.DriverID,
                                FirstName = details.FirstName,
                                LastName = details.LastName,
                                StartTime = log.StartTime,
                                EndTime = log.EndTime,
                                ViolationHours = violationHours  
                            };
                        })
                    .ToList();

                var dayDriveTimeViolations = _context.DailyActivityLogs.AsEnumerable()
                  .Where(log => (log.EndTime - log.StartTime).TotalHours > 12)
                  .GroupBy(log => new {
                      log.DriverID,
                      Date = log.StartTime.Date
                  })
                  .SelectMany(group => group
                    .Join(driverDetails,
                      log => log.DriverID,
                      details => details.DriverId,
                      (log, details) => new ViolationDetailsDTO
                      {
                          DriverID = log.DriverID,
                          FirstName = details.FirstName,
                          LastName = details.LastName,
                          StartTime = log.StartTime,
                          EndTime = log.EndTime,
                          ViolationHours = (log.EndTime - log.StartTime).TotalHours.ToString("0.00")
                      })
                    .ToList())
                  .ToList();

                var weekDriveTimeViolations = _context.DailyActivityLogs.AsEnumerable()
                  .Where(log => (log.EndTime - log.StartTime).TotalHours > 60)
                  .GroupBy(log => new {
                      log.DriverID,
                      WeekNumber = GetIso8601WeekOfYear(log.StartTime)
                  })
                  .SelectMany(group => group
                    .Join(driverDetails,
                      log => log.DriverID,
                      details => details.DriverId,
                      (log, details) => new ViolationDetailsDTO
                      {
                          DriverID = log.DriverID,
                          FirstName = details.FirstName,
                          LastName = details.LastName,
                          StartTime = log.StartTime,
                          EndTime = log.EndTime,
                          ViolationHours = (log.EndTime - log.StartTime).TotalHours.ToString("0.00")
                      })
                    .ToList())
                  .ToList();

                var dashboardDto = new DashboardDTO
                {
                    TotalDrivingTime = totalDrivingTime,
                    TotalRestTime = totalRestTime,
                    ExceededDriveTimeViolations = violations,
                    RestTimeViolations = restTimeViolations,
                    DayDriveTimeViolations = dayDriveTimeViolations,
                    WeekDriveTimeViolations = weekDriveTimeViolations
                };

                return dashboardDto;
            }
            catch (Exception ex)
            {
                _logger.LogError("{DriverDetailsRepository - GetDashBoardData}", ex.Message);
                throw;
            }
        }

        // Helper method to get ISO 8601 week number for a given date
        private int GetIso8601WeekOfYear(DateTime date)
        {
            var cal = System.Globalization.DateTimeFormatInfo.CurrentInfo.Calendar;
            return cal.GetWeekOfYear(date, System.Globalization.CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

    }
}