﻿
using Microsoft.Extensions.Configuration;
using Tachograph.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Tachograph.Data.Context
{
    public class TachographDBContext:DbContext
    {
        protected readonly IConfiguration Configuration;

        public TachographDBContext(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseNpgsql(Configuration.GetConnectionString("PostgresConnection"));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DailyActivityLogs>().ToTable("DailyActivityLogs");
        }

        public DbSet<DailyActivityLogs> DailyActivityLogs { get; set; }
    }
}
