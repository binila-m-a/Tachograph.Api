﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tachograph.Data.Models;
using Tachograph.Entity.DTOs;

namespace Tachograph.Business.ApiDataLink
{
    public interface IDriverDataLink
    {
        Task<List<DriverDetailsDTO>> GetAllDriverList();
        Task<string> CreateDailyDriverActivity(DailyActivityLogDTO dailyActivityLogDTO);

        Task<DashboardDTO> GetDashBoardData();
    }

    
}
