﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tachograph.Business.ApiDataLink;
using Tachograph.Entity.Common;
using Tachograph.Entity.DTOs;

namespace Tachograph.Api.Controllers.DashBoard
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : Controller
    {
        private readonly ILogger<DashboardController> _logger;
        private readonly IDriverDataLink driverDataLink;
        public DashboardController(ILogger<DashboardController> logger, IDriverDataLink driverDataLink)
        {
            _logger = logger;
            this.driverDataLink = driverDataLink;
        }
        [HttpGet]
        [Route("GetDashBoarddata")]
        public async Task<ApiResponse<DashboardDTO>> GetDashBoarddata()
        {
            try
            {
                var result = await driverDataLink.GetDashBoardData();
                return new ApiResponse<DashboardDTO>(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("{Dashboard-GetDashBoarddata}", ex.Message);
                return new ApiResponse<DashboardDTO>(ex);
            }
        }



    }
}
