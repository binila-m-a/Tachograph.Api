using Amazon.DynamoDBv2.DataModel;
using Microsoft.AspNetCore.Mvc;
using Tachograph.Data.Models;

namespace Tachograph.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IDynamoDBContext _context;

        public WeatherForecastController(IDynamoDBContext context)
        {
            _context = context;
        }

        [HttpGet("{id}/{barcode}")]
        public async Task<IActionResult> Get(string id, string barcode)
        {
            var product = await _context.LoadAsync<DriverDetails>(id, barcode);
            if (product == null) return NotFound();
            return Ok(product);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var products = await _context.ScanAsync<DriverDetails>(default).GetRemainingAsync();
            return Ok(products);
        }

        [HttpPost]
        public async Task<IActionResult> Create(DriverDetails request)
        {
          
            await _context.SaveAsync(request);
            return Ok(request);
        }

        [HttpDelete("{id}/{barcode}")]
        public async Task<IActionResult> Delete(string id, string barcode)
        {
            var product = await _context.LoadAsync<DriverDetails>(id, barcode);
            if (product == null) return NotFound();
            await _context.DeleteAsync(product);
            return NoContent();
        }

        [HttpPut]
        public async Task<IActionResult> Update(DriverDetails request)
        {
            var product = await _context.LoadAsync<DriverDetails>(request.FirstName, request.LastName);
            if (product == null) return NotFound();
            await _context.SaveAsync(request);
            return Ok(request);
        }
    }
}
       