﻿using System.Text.Json;
using Tachograph.Entity.DTOs;

namespace Tachograph.Api.Middlewares
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionMiddleware> _logger;

        public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }
        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (HttpRequestException ex)
            {
                await HandleHttpExceptionAsync(httpContext, ex, (int)((HttpRequestException)ex).StatusCode);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception Caught: {ex.Message} || {ex}");
                await HandleExceptionAsync(httpContext, ex);
            }
        }
        private async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            string result;
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = 500;

            result = JsonSerializer.Serialize(new ErrorResponseDTO { Exception = ex.Message, Message = "Internal Server Error" });
            await context.Response.WriteAsync(result);
        }

        private async Task HandleHttpExceptionAsync(HttpContext context, Exception ex, int statusCode)
        {
            string result;
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = statusCode;

            result = JsonSerializer.Serialize(new ErrorResponseDTO { Exception = ex.Message, Message = "Bad Request" });
            await context.Response.WriteAsync(result);
        }
    }
}
