﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tachograph.Data.Models;
using Tachograph.Entity.DTOs;

namespace Tachograph.Business.AutoMapper
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<DriverDetails, DriverDetailsDTO>();
            CreateMap<DailyActivityLogDTO, DailyActivityLogs>();
        }
    }
}