﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tachograph.Entity.DTOs
{
    public class DashboardDTO
    {
        public TimeSpan TotalDrivingTime { get; set; }
        public TimeSpan TotalRestTime { get; set; }
        public List<ViolationDetailsDTO> ExceededDriveTimeViolations { get; set; }
        public List<ViolationDetailsDTO> RestTimeViolations { get; set; }
        public List<ViolationDetailsDTO> DayDriveTimeViolations { get; set; }
        public List<ViolationDetailsDTO> WeekDriveTimeViolations { get; set; }
    }
}
