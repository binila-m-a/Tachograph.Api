﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tachograph.Data.Models;
using Tachograph.Data.Repository;
using Tachograph.Entity.DTOs;

namespace Tachograph.Business.ApiDataLink
{
   
    public  class DriverDataLink: IDriverDataLink
    {
        private readonly ILogger<DriverDataLink> _logger;
        private readonly IDriverRepository driverRepository;
        private readonly IMapper _mapper;
        public DriverDataLink(ILogger<DriverDataLink> logger, IDriverRepository driverRepository, IMapper mapper)
        {
            _logger = logger;
            this.driverRepository = driverRepository;
            _mapper= mapper;
        }
        public async Task<List<DriverDetailsDTO>> GetAllDriverList()
        {
            try
            {
                _logger.LogInformation("{DriverDataLink-GetAllDriverList}", "Method to get all driver details started");
                var result = await driverRepository.GetAllDriverList();
                List<DriverDetailsDTO> driverDetailsDTOs = _mapper.Map<List<DriverDetailsDTO>>(result).ToList();
                _logger.LogInformation("{DriverDataLink-GetAllDriverList}", "Method to get all driver details completed");
                return driverDetailsDTOs;
            }
            catch (Exception ex)
            {
                _logger.LogError("{DriverDataLink-GetAllDriverList}", ex.Message);
                throw;
            }
        }

        public async Task<string> CreateDailyDriverActivity(DailyActivityLogDTO dailyActivityLogDTO)
        {
            try
            {
                _logger.LogInformation("{DriverDataLink-CreateDailyDriverActivity}", "Method to create daily driver activity started.");
                var dailyActivityLogs = _mapper.Map<DailyActivityLogs>(dailyActivityLogDTO);
                var dailyactivity = await driverRepository.SaveDailyDriverActivity(dailyActivityLogs);
            
                _logger.LogInformation("{DriverDataLink-CreateDailyDriverActivity}", "Method to create daily driver activity completed.");
                return dailyactivity;

            }
            catch (Exception ex)
            {
                _logger.LogError("{DriverDataLink-CreateDailyDriverActivity}", ex.Message);
                throw;
            }
        }


        public async Task<DashboardDTO> GetDashBoardData()
        {
            try
            {
                _logger.LogInformation("{DriverDataLink-GetDashBoardData}", "Method to get dashboard details started");
                var result = await driverRepository.GetDashBoardData();
                _logger.LogInformation("{DriverDataLink-GetDashBoardData}", "Method to get dashboard details completed");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError("{DriverDataLink-GetDashBoardData}", ex.Message);
                throw;
            }
        }
    }
}
