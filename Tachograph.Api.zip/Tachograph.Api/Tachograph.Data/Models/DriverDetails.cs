﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Tachograph.Data.Models
{
    [DynamoDBTable("DriverDetails")]
    public class DriverDetails
    {
        [DynamoDBHashKey]
        public string DriverId { get; set; }

        [DynamoDBProperty]
        public string FirstName { get; set; }

        [DynamoDBProperty]
        public string LastName { get; set; }

        [DynamoDBProperty]
        public string Address { get; set; }

        [DynamoDBProperty]
        public string MobileNumber { get; set; }

        [DynamoDBProperty]
        public string Nationality { get; set; }

        [DynamoDBProperty]
        public string LicenseNumber { get; set; }

        [DynamoDBProperty]
        public string Status { get; set; }
    }

}
