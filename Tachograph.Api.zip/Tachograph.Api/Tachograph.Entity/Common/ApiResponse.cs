﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tachograph.Entity.Common
{
    public class ApiResponse<T>
    {

        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public int Total { get; set; }

     

        public ApiResponse(bool isSuccess, string message, T data)
        {
            IsSuccess = isSuccess;
            Message = message;
            Data = data;
        }

        public ApiResponse(T data)
        {
            IsSuccess = true;
            Message = string.Empty;
            Data = data;
        }

        public ApiResponse(T data, int total)
        {
            IsSuccess = true;
            Message = string.Empty;
            Data = data;
            Total = total;
        }

        public ApiResponse(Exception ex)
        {
            IsSuccess = false;
            //Message = ex.Message + ex.StackTrace;
            if (ex.Message == "401/unauthorised")
                Message = ex.Message;
            else if (ex.Message == "sessionExpired")
                Message = ex.Message;
            else if (ex.Message.Contains("PerformatrixError"))
                Message = ex.Message.Replace("PerformatrixError:", "");
            else
                Message = "Internal Server Error: Something went wrong";
        }
    }
}
