﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tachograph.Data.Models;
using Tachograph.Entity.DTOs;

namespace Tachograph.Data.Repository
{
    public interface IDriverRepository
    {
        Task<List<DriverDetails>> GetAllDriverList();
        Task<string> SaveDailyDriverActivity(DailyActivityLogs dailyActivityLogs);
        Task<DashboardDTO> GetDashBoardData();
    }
}

