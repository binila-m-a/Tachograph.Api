﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tachograph.Entity.DTOs
{
    public class DailyActivityLogDTO
    {
        public long UniqueID { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string DriverID { get; set; }
        public string Activity { get; set; }
        public DateTime? InsertedOn { get; set; }
        public string? InsertedBy { get; set; }
    }
}
