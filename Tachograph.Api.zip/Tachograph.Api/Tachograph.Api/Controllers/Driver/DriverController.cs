﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tachograph.Business.ApiDataLink;
using Tachograph.Entity.Common;
using Tachograph.Entity.DTOs;

namespace Tachograph.Api.Controllers.Driver
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriverController : ControllerBase
    {
        private readonly ILogger<DriverController> _logger;
        private readonly IDriverDataLink driverDataLink;

        public DriverController(ILogger<DriverController> logger,IDriverDataLink driverDataLink)
        {
            _logger = logger;
            this.driverDataLink = driverDataLink;
        }

        [HttpGet]
        [Route("GetDriversList")]
        public async Task<ActionResult<ApiResponse<List<DriverDetailsDTO>>>> GetDriversList()
        {
            try
            {

                var result = await this.driverDataLink.GetAllDriverList();
                return new ApiResponse<List<DriverDetailsDTO>>(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Driver-GetDriversList");
                return StatusCode(StatusCodes.Status500InternalServerError, new ApiResponse<List<DriverDetailsDTO>>(ex));
            }
        }

        [HttpPost]
        [Route("PostDailyDriverActivity")]
        public async Task<ActionResult<ApiResponse<string>>> PostDailyDriverActivity( DailyActivityLogDTO dailyActivityLogDTO)
        {
            try
            {

                var result = await this.driverDataLink.CreateDailyDriverActivity(dailyActivityLogDTO);

                return new ApiResponse<string>(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Driver-PostDailyDriverActivity");
                return StatusCode(StatusCodes.Status500InternalServerError, new ApiResponse<List<DriverDetailsDTO>>(ex));
            }
        }
    }
} 
