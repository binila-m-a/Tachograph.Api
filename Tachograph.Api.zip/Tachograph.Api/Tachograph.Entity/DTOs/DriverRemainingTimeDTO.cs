﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tachograph.Entity.DTOs
{
    public class DriverRemainingTimeDTO
    {
        public TimeSpan RemainingDrivingTime { get; set; }
        public TimeSpan RemainingRestTime { get; set; }
        public DateTime? NextDailyRest { get; set; }
    }
}
